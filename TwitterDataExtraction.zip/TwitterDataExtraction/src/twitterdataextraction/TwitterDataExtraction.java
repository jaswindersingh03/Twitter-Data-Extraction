/*
 * Jaswinder Singh
 * Date: 24-04-2016
 * Twitter Data Extraction
 */
package twitterdataextraction;
import java.util.List;
import twitter4j.*;
import twitter4j.conf.ConfigurationBuilder;
import java.io.*;
/**
 *
 * @author Jaswinder Singh
 */
public class TwitterDataExtraction {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws TwitterException, IOException {
        ConfigurationBuilder cf = new ConfigurationBuilder();
         cf.setDebugEnabled(true)
          .setOAuthConsumerKey("Enter Valid Consumer Key")
           .setOAuthConsumerSecret("Enter Valid Consumer secret")
           .setOAuthAccessToken("Enter valid Access Token")
           .setOAuthAccessTokenSecret("Enter valid Access Token Secret");
        
        TwitterFactory tf = new TwitterFactory(cf.build());
        twitter4j.Twitter twitter = tf.getInstance();
        twitter4j.User newUser=twitter.showUser(twitter.getScreenName());
        String name=newUser.getScreenName();
        List<Status> status = twitter.getUserTimeline();
        int count=0;
        for(Status st : status)
        {
            count++;
        }
        System.out.println("Twitter Handle Is : "+name);
        System.out.println("Number of Tweets done : "+count);
        File data = new File("ExtractedData.txt");
        FileWriter fw = new FileWriter(data.getAbsoluteFile());
            //FileOutputStream is = new FileOutputStream(args[1]);
            //OutputStreamWriter osw = new OutputStreamWriter(is);    
            Writer w = new BufferedWriter(fw);
            w.write("Twitter Handle Is : "+name+"\r\n");
            w.write("Number of Tweets done : "+count);            
            w.close();
    }
    
}
